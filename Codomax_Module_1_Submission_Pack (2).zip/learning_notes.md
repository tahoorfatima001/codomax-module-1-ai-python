# Module 1 Learning Notes: Introduction to AI & Python

**Student:** Tahoor Fatima  
**Organisation:** Codomax Digital Solutions  
**Module:** 1 — Introduction to AI & Python

## 1. What is Artificial Intelligence (AI)?
Artificial Intelligence is a field of computer science that develops computer systems able to perform tasks that normally require human-like intelligence. Examples include understanding language, recognising images, recommending videos, and helping users through chatbots.

## 2. AI vs Machine Learning vs Deep Learning
- **Artificial Intelligence (AI):** The broad field of making machines perform intelligent tasks.
- **Machine Learning (ML):** A part of AI in which a computer learns patterns from data rather than relying only on manually written rules.
- **Deep Learning (DL):** A part of ML that uses neural networks with many layers. It is useful for tasks such as image recognition, speech recognition, and generative AI.

**Relationship:** Deep Learning is a type of Machine Learning, and Machine Learning is a type of AI.

## 3. Real-world applications of AI
1. **Healthcare:** Assisting with medical-image analysis and identifying patterns in health data.
2. **Agriculture:** Detecting crop diseases, monitoring soil and weather, and supporting yield estimates.
3. **Education:** Personalised learning tools and tutoring assistants.
4. **Banking:** Fraud detection and customer-service chatbots.
5. **Transport:** Route planning and driver-assistance systems.
6. **Shopping and entertainment:** Product, music, and video recommendations.

## 4. Benefits and limitations of AI
**Benefits:** Can process large amounts of data, automate repetitive work, identify patterns, and support decision-making.

**Limitations:** Results can be inaccurate, biased, or difficult to explain. Systems may require high-quality data and computing resources. Human review, privacy, and responsible use remain important.

## 5. Introduction to Python
Python is a high-level, general-purpose programming language known for readable syntax. It is used in data analysis, automation, web development, AI, and scientific computing.

## 6. Python basics

### Variables and data types
A variable stores a value. Common types include:
- `int`: whole numbers, e.g. `19`
- `float`: decimal numbers, e.g. `87.5`
- `str`: text, e.g. `"Python"`
- `bool`: `True` or `False`
- `list`: an ordered, changeable collection, e.g. `[10, 20, 30]`

### Conditions
`if`, `elif`, and `else` allow a program to choose between actions based on a condition.

### Loops
- A `for` loop repeats over items in a sequence.
- A `while` loop repeats while a condition remains true.

### Lists
Lists store multiple items in one variable. Indexing starts at `0`. Common operations include `append()`, `len()`, and accessing an item by index.

### Functions
A function is a reusable block of code defined with `def`. It can accept inputs (parameters) and return a result.

## 7. Learning reflection
In this module, I learned the basic difference between AI, ML, and Deep Learning and explored examples of AI in daily life. I also practised core Python concepts including variables, conditions, loops, lists, and functions. These foundations will help me progress towards data analysis and machine learning.

## 8. Conclusion
AI is a broad area that supports intelligent applications, while ML and DL are approaches used to build many of these systems. Python is a useful beginner-friendly language for learning programming and later working with data science and AI.
