# Variables and data types
student_name = "Tahoor Fatima"
age = 19
percentage = 87.2
is_learning_python = True

print("Student:", student_name)
print("Age:", age)
print("Percentage:", percentage)
print("Learning Python:", is_learning_python)
print("Type of age:", type(age).__name__)
