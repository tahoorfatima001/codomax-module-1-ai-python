# A simple function
def calculate_average(numbers):
    """Return the average of a list of numbers."""
    if len(numbers) == 0:
        return 0
    return sum(numbers) / len(numbers)

scores = [78, 90, 85, 92]
average = calculate_average(scores)
print("Scores:", scores)
print("Average score:", average)
