# For loop: print numbers from 1 to 5
print("For loop:")
for number in range(1, 6):
    print(number)

# While loop: count down from 3 to 1
print("While loop:")
count = 3
while count > 0:
    print(count)
    count -= 1
print("Finished!")
