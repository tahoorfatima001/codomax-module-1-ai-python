# Beginner-friendly calculator
first = float(input("Enter the first number: "))
operator = input("Choose an operation (+, -, *, /): ")
second = float(input("Enter the second number: "))

if operator == "+":
    print("Result:", first + second)
elif operator == "-":
    print("Result:", first - second)
elif operator == "*":
    print("Result:", first * second)
elif operator == "/":
    if second != 0:
        print("Result:", first / second)
    else:
        print("Error: division by zero is not allowed.")
else:
    print("Unknown operation. Please choose +, -, *, or /.")
