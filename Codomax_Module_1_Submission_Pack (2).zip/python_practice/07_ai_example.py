# A simple rule-based assistant example.
# This demonstrates fixed rules; it is NOT machine learning.
message = input("Hi! Ask for help with: study, python, or greeting: ").strip().lower()

if "study" in message:
    print("Suggestion: Choose one topic, study for 25 minutes, then take a 5-minute break.")
elif "python" in message:
    print("Suggestion: Practise variables, conditions, loops, lists, and functions.")
elif "greeting" in message or "hello" in message or "hi" in message:
    print("Hello! How can I help you learn today?")
else:
    print("I am a simple rule-based assistant, so I do not understand that request yet.")
