# Lists and basic operations
subjects = ["Economics", "Python", "Mathematics"]
print("Subjects:", subjects)
print("First subject:", subjects[0])

subjects.append("Data Science")
print("After adding a subject:", subjects)
print("Number of subjects:", len(subjects))

for subject in subjects:
    print("-", subject)
