# Codomax Digital Solutions — Module 1: Introduction to AI & Python

**Student:** Tahoor Fatima  
**Module:** 1 — Introduction to AI & Python  
**Level:** Beginner

## What this project covers
- Basic concepts of Artificial Intelligence (AI), Machine Learning (ML), and Deep Learning (DL)
- Real-world applications of AI
- Python variables, data types, conditionals, loops, lists, and functions
- Beginner-friendly Python programs

## Files
- `learning_notes.md` — concise learning notes
- `python_practice/01_variables.py` — variables and data types
- `python_practice/02_conditions.py` — if/elif/else
- `python_practice/03_loops.py` — for and while loops
- `python_practice/04_lists.py` — list operations
- `python_practice/05_functions.py` — functions
- `python_practice/06_simple_calculator.py` — small practical program
- `python_practice/07_ai_example.py` — a simple rule-based “AI-style” example

## How to run
1. Install Python 3.
2. Open this folder in VS Code.
3. Open a `.py` file.
4. Click **Run Python File** or run `python filename.py` in the terminal.

These are beginner practice examples created for learning. The rule-based example is not a trained machine-learning model.
